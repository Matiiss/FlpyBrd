# HOW TO RUN THE GAME
Double click FlpyBrd.exe (or run it from a shell), after it exits it will wait for your input,
in the opened console you will see your score, press enter when you want to exit (or just close the window)

# CONTROLS
Space bar - that's it, it will make the brd jump

# MORE INFO
Survive as long as possible, don't collide with the clmns and don't leave the game window,
score is determined based on the time